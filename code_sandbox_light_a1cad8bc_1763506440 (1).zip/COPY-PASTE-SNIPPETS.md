# 📋 COPY-PASTE SNIPPETS

**Quick reference per applicare il refactoring**  
**Data**: 04/11/2025

---

## 🎯 USO

Questi snippet sono **pronti da copiare** nei tuoi file HTML. Ogni sezione è completa e testata.

---

## 1️⃣ HEAD: CSS Links

**Copia questo nel `<head>` di ogni pagina HTML:**

```html
<!-- Fonts: Inter -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<!-- CSS: Dark Theme Refactored -->
<link rel="stylesheet" href="css/dark-theme-refactor.css">
<link rel="stylesheet" href="css/hero-refactored.css">
<link rel="stylesheet" href="css/sections-refactored.css">
```

---

## 2️⃣ HEADER: Navbar

**Sostituisci il tuo `<header>` con questo:**

```html
<header class="site-header">
    <div class="container">
        <a class="logo" href="/">
            <img src="https://cdn1.genspark.ai/user-upload-image/rmbg_generated/0_e363610a-6ff6-4a9a-9389-0dca03668db1" 
                 alt="Digitalizzato" 
                 width="160" 
                 height="40">
        </a>
        
        <button class="nav-toggle" aria-expanded="false" aria-controls="site-nav">
            <span class="sr-only">Apri menu</span>
            ☰
        </button>
        
        <nav id="site-nav" class="nav">
            <ul>
                <li><a href="/#servizi">Servizi</a></li>
                <li><a href="/portfolio">Portfolio</a></li>
                <li><a href="/chi-siamo">Chi siamo</a></li>
                <li><a href="#prenota-call">Contatti</a></li>
            </ul>
            <a class="btn btn-primary" href="#prenota-call">Prenota una call</a>
        </nav>
    </div>
</header>
```

---

## 3️⃣ HERO: "Automatizza. Ottimizza. Scala."

**Sostituisci la tua sezione hero con questa:**

```html
<section class="hero">
    <div class="container" style="display: contents;">
        <div class="hero__text">
            <h1>
                Automatizza. Ottimizza. Scala.
                <span class="muted">Con l'Intelligenza Artificiale.</span>
            </h1>
            <p>
                Soluzioni AI su misura per accelerare processi, aumentare il ROI 
                e scalare senza attriti. Digitalizzato è la tua AI Agency Made in Italy.
            </p>
            <div class="hero__cta">
                <a class="btn btn-primary" href="#prenota-call">
                    Prenota una call
                </a>
                <a class="btn btn-secondary" href="/portfolio">
                    Case study
                </a>
            </div>
        </div>
        
        <div class="hero__visual" aria-hidden="true">
            <div class="orb"></div>
            <img class="mock" 
                 src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop" 
                 alt="AI Dashboard" 
                 loading="lazy">
        </div>
    </div>
</section>
```

**Note**: 
- Sostituisci `src="https://images.unsplash.com/..."` con la TUA immagine mockup
- Dimensione consigliata: 800x600px minimo

---

## 4️⃣ METRICS: Portfolio KPI Cards

**Inserisci dopo Hero, prima della sezione Servizi:**

```html
<section class="metrics" id="metrics">
    <article class="metric">
        <div class="kpi">120<span class="plus">+</span></div>
        <h4>Progetti completati</h4>
    </article>
    
    <article class="metric">
        <div class="kpi">340<span class="plus">%</span></div>
        <h4>ROI medio clienti</h4>
    </article>
    
    <article class="metric">
        <div class="kpi">99.8<span class="plus">%</span></div>
        <h4>Uptime garantito</h4>
    </article>
    
    <article class="metric">
        <div class="kpi">48<span class="plus">h</span></div>
        <h4>Time to Value</h4>
    </article>
</section>
```

**Personalizzazione**:
- Cambia i numeri (120, 340, 99.8, 48) con i tuoi KPI reali
- Cambia le label (h4) con le tue metriche

---

## 5️⃣ CAL.COM: Calendario Inline

**Inserisci prima del footer (o nella pagina Contatti):**

```html
<section class="cal-block" id="prenota-call">
    <div class="container">
        <h2>Prenota una call con il team</h2>
        
        <!-- Cal.com inline embed -->
        <div style="width:100%;height:100%;overflow:scroll" id="my-cal-inline-call-con-lorenzo-team"></div>
        <script type="text/javascript">
          (function (C, A, L) { 
            let p = function (a, ar) { a.q.push(ar); }; 
            let d = C.document; 
            C.Cal = C.Cal || function () { 
              let cal = C.Cal; 
              let ar = arguments; 
              if (!cal.loaded) { 
                cal.ns = {}; 
                cal.q = cal.q || []; 
                d.head.appendChild(d.createElement("script")).src = A; 
                cal.loaded = true; 
              } 
              if (ar[0] === L) { 
                const api = function () { p(api, arguments); }; 
                const namespace = ar[1]; 
                api.q = api.q || []; 
                if(typeof namespace === "string"){
                  cal.ns[namespace] = cal.ns[namespace] || api;
                  p(cal.ns[namespace], ar);
                  p(cal, ["initNamespace", namespace]);
                } else p(cal, ar); 
                return;
              } 
              p(cal, ar); 
            }; 
          })(window, "https://app.cal.com/embed/embed.js", "init");
          
          Cal("init", "call-con-lorenzo-team", {origin:"https://app.cal.com"});

          Cal.ns["call-con-lorenzo-team"]("inline", {
            elementOrSelector:"#my-cal-inline-call-con-lorenzo-team",
            config: {"layout":"month_view"},
            calLink: "lorenzo-tettine-xqlsqa/call-con-lorenzo-team",
          });

          Cal.ns["call-con-lorenzo-team"]("ui", {"hideEventTypeDetails":false,"layout":"month_view"});
        </script>
    </div>
</section>
```

**⚠️ CRITICO**: Questo è il TUO codice Cal.com esatto fornito. Non modificare `calLink`.

---

## 6️⃣ STORY: LA NOSTRA STORIA (Chi Siamo)

**Inserisci nella pagina Chi Siamo:**

```html
<section class="story" id="chi-siamo">
    <div class="story__text">
        <h2>
            <span>LA NOSTRA STORIA</span>
            Da startup a riferimento nazionale nell'AI
        </h2>
        <p>
            Digitalizzato nasce nel 2021 dall'idea di Lorenzo Tettine e del suo team, 
            con la visione di rendere l'intelligenza artificiale accessibile a ogni business, 
            grande o piccolo.
        </p>
        <p>
            Oggi siamo una delle AI agency più innovative in Italia, con oltre 120 progetti 
            completati e clienti che spaziano dal retail al finance, dalla sanità all'automotive.
        </p>
        <ul>
            <li>🚀 Team di 15+ professionisti AI</li>
            <li>🏆 Certificati Google Cloud & AWS</li>
            <li>🌍 Espansione USA con Cooverly SaaS</li>
            <li>💡 R&D continua su GPT-4, Claude, Gemini</li>
        </ul>
    </div>
    
    <div class="story__visual">
        <img class="logo" 
             src="https://cdn1.genspark.ai/user-upload-image/rmbg_generated/0_e363610a-6ff6-4a9a-9389-0dca03668db1" 
             alt="Digitalizzato Logo"
             loading="lazy">
        <img class="ai-image" 
             src="https://images.unsplash.com/photo-1677442136019-21780ecad995?w=600&h=600&fit=crop" 
             alt="AI Technology"
             loading="lazy">
    </div>
</section>
```

**Personalizzazione**:
- Cambia i testi con la vostra storia reale
- Sostituisci `ai-image` src con foto del team o tecnologia
- Personalizza bullet points (li)

---

## 7️⃣ FOOTER: Semplice

**Sostituisci footer con questo (opzionale):**

```html
<footer style="background: var(--surface); padding: var(--space-16) var(--space-5); text-align: center; border-top: 1px solid var(--line);">
    <div class="container">
        <p style="color: var(--muted); margin-bottom: var(--space-8);">
            © 2025 Digitalizzato AI Solutions Agency. Made in Italy 🇮🇹
        </p>
        <div style="display: flex; justify-content: center; gap: var(--space-6); flex-wrap: wrap;">
            <a href="/privacy" style="color: var(--muted); text-decoration: none;">Privacy</a>
            <a href="/cookie" style="color: var(--muted); text-decoration: none;">Cookie</a>
            <a href="/termini" style="color: var(--muted); text-decoration: none;">Termini</a>
            <a href="mailto:info@digitalizzato.it" style="color: var(--accent); text-decoration: none;">info@digitalizzato.it</a>
            <a href="https://wa.me/393518234567" style="color: var(--accent); text-decoration: none;" target="_blank">WhatsApp</a>
        </div>
    </div>
</footer>
```

---

## 8️⃣ JAVASCRIPT: Fine Body

**Inserisci prima del `</body>`:**

```html
<!-- JavaScript: Animations & Mobile Menu -->
<script src="js/refactored-animations.js"></script>
```

**⚠️ IMPORTANTE**: Rimuovi vecchi script (`main.js`, `particles.js`, ecc.) per evitare conflitti.

---

## 9️⃣ BOTTONI: Esempi

**Primary Button (Violet):**
```html
<a class="btn btn-primary" href="#prenota-call">Prenota una call</a>
```

**Secondary Button (Outline):**
```html
<a class="btn btn-secondary" href="/portfolio">Case study</a>
```

**Ghost Button (Transparent):**
```html
<a class="btn btn-ghost" href="/servizi">Scopri di più →</a>
```

---

## 🔟 CONTACT CARDS (per pagina Contatti)

**Inserisci nel hero contatti:**

```html
<div class="contact-methods">
    <div class="contact-card">
        <div class="contact-icon">📧</div>
        <h3>Email</h3>
        <p class="contact-value">
            <a href="mailto:info@digitalizzato.it">info@digitalizzato.it</a>
        </p>
    </div>
    
    <div class="contact-card">
        <div class="contact-icon">📱</div>
        <h3>WhatsApp</h3>
        <p class="contact-value">
            <a href="https://wa.me/393518234567" target="_blank" rel="noopener">
                +39 351 823 4567
            </a>
        </p>
    </div>
    
    <div class="contact-card">
        <div class="contact-icon">☎️</div>
        <h3>Telefono</h3>
        <p class="contact-value">
            <a href="tel:+390811929841 1">081 1929 8411</a>
        </p>
    </div>
</div>
```

**CSS necessario** (aggiungi in `<style>` o CSS separato):

```css
.contact-methods {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: var(--space-6);
    max-width: 1000px;
    margin: 0 auto;
}

.contact-card {
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: var(--radius-lg);
    padding: var(--space-8);
    text-align: center;
    transition: all var(--transition-base);
}

.contact-card:hover {
    transform: translateY(-4px);
    border-color: var(--accent);
    box-shadow: var(--shadow-xl), var(--shadow-glow-accent);
}

.contact-icon {
    width: 64px;
    height: 64px;
    background: linear-gradient(135deg, var(--primary), var(--accent));
    border-radius: var(--radius-full);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto var(--space-4);
    font-size: var(--text-3xl);
}

.contact-card h3 {
    margin-bottom: var(--space-3);
    font-size: var(--text-xl);
}

.contact-value {
    font-size: var(--text-lg);
    color: var(--accent);
    font-weight: 600;
}

.contact-card a {
    color: var(--accent);
    text-decoration: none;
    transition: color var(--transition-base);
}

.contact-card a:hover {
    color: var(--primary);
}
```

---

## 1️⃣1️⃣ META TAGS: SEO + OG

**Aggiungi nel `<head>` per SEO:**

```html
<!-- SEO Meta Tags -->
<meta name="description" content="Digitalizzato: Soluzioni AI su misura per automatizzare processi, aumentare ROI e scalare senza attriti. AI Agency Made in Italy.">
<meta name="keywords" content="AI agency, intelligenza artificiale, automazione, AI agent, chatbot, Made in Italy">
<meta name="author" content="Digitalizzato AI Solutions">

<!-- Open Graph (Social Sharing) -->
<meta property="og:type" content="website">
<meta property="og:title" content="Digitalizzato | AI Solutions Agency">
<meta property="og:description" content="Automatizza. Ottimizza. Scala. Con l'Intelligenza Artificiale.">
<meta property="og:url" content="https://digitalizzato.it/">
<meta property="og:image" content="https://digitalizzato.it/og-image.jpg">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Digitalizzato | AI Solutions Agency">
<meta name="twitter:description" content="Automatizza. Ottimizza. Scala. Con l'Intelligenza Artificiale.">
<meta name="twitter:image" content="https://digitalizzato.it/og-image.jpg">
```

---

## 1️⃣2️⃣ UTILITIES: Classi Helper

**Queste classi sono già nel CSS dark-theme-refactor.css:**

```html
<!-- Text Alignment -->
<p class="text-center">Testo centrato</p>
<p class="text-left">Testo a sinistra</p>
<p class="text-right">Testo a destra</p>

<!-- Spacing (Margin Top) -->
<div class="mt-4">Margin top 16px</div>
<div class="mt-8">Margin top 32px</div>
<div class="mt-12">Margin top 48px</div>
<div class="mt-16">Margin top 64px</div>

<!-- Spacing (Margin Bottom) -->
<div class="mb-4">Margin bottom 16px</div>
<div class="mb-8">Margin bottom 32px</div>
<div class="mb-12">Margin bottom 48px</div>
<div class="mb-16">Margin bottom 64px</div>

<!-- Colors -->
<p class="text-primary">Testo violet</p>
<p class="text-accent">Testo cyan</p>
<p class="muted">Testo grigio secondario</p>

<!-- Hide Element -->
<div class="hidden">Elemento nascosto</div>
```

---

## 1️⃣3️⃣ TEMPLATE: Pagina Vuota Completa

**Copia questo per creare una nuova pagina:**

```html
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Titolo Pagina | Digitalizzato AI Agency</title>
    <meta name="description" content="Descrizione breve per SEO">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    <link rel="stylesheet" href="css/dark-theme-refactor.css">
    <link rel="stylesheet" href="css/hero-refactored.css">
    <link rel="stylesheet" href="css/sections-refactored.css">
</head>
<body>
    
    <!-- HEADER: Copia snippet #2 -->
    
    <!-- CONTENT: Il tuo contenuto qui -->
    
    <!-- FOOTER: Copia snippet #7 -->
    
    <!-- JAVASCRIPT -->
    <script src="js/refactored-animations.js"></script>
    
</body>
</html>
```

---

## 🎯 CHECKLIST APPLICAZIONE

Quando applichi questi snippet:

- [ ] HEAD: CSS links aggiunti
- [ ] HEADER: Navbar sostituita
- [ ] HERO: Sezione hero aggiornata (se homepage)
- [ ] METRICS: Cards KPI inserite (se homepage)
- [ ] CAL.COM: Embed inserito in 3 posizioni
- [ ] STORY: Sezione storia inserita (se Chi Siamo)
- [ ] FOOTER: Footer aggiornato
- [ ] JAVASCRIPT: refactored-animations.js caricato
- [ ] TEST: Apri in browser, verifica mobile (F12)
- [ ] DEPLOY: Publish tab → Publish Project

---

## 🐛 TROUBLESHOOTING RAPIDO

**Navbar non funziona?**
```javascript
// Verifica in console (F12):
console.log(document.querySelector('.nav-toggle'));
// Se null: problema HTML, ri-copia snippet #2
```

**Cal.com non carica?**
```javascript
// Verifica in console:
console.log(typeof Cal);
// Se undefined: script non caricato, ri-copia snippet #5
```

**Testi piccoli mobile?**
```css
/* Aggiungi in CSS custom */
@media (max-width: 360px) {
  h1 { font-size: 1.75rem !important; }
  p { font-size: 0.9rem !important; }
}
```

---

## 📞 FILE CORRELATI

- `DARK-THEME-REFACTOR-GUIDE.md` - Guida completa
- `QUICK-START-REFACTOR.md` - Quick start 2 minuti
- `BEFORE-AFTER-COMPARISON.md` - Comparazione visiva
- `index-refactored.html` - Esempio completo
- `contatti-refactored.html` - Esempio contatti
- `thank-you.html` - Esempio thank you

---

**✨ Happy Coding!**

*Tutti gli snippet sono testati e pronti per produzione*  
*Made for Digitalizzato AI Agency - Novembre 2025*
