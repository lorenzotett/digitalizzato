// Portfolio Page Interactivity

// ========== DEMO CHAT FUNCTIONALITY ==========
const demoChatInput = document.getElementById('demo-chat-input');
const demoChatSend = document.getElementById('demo-chat-send');
const demoChatMessages = document.getElementById('demo-chat-messages');
const quickButtons = document.querySelectorAll('.quick-btn');

function addDemoMessage(text, sender = 'user') {
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${sender}`;
    
    if (sender === 'bot') {
        messageDiv.innerHTML = `
            <div class="message-avatar">
                <div class="avatar-placeholder tiny">G</div>
            </div>
            <div class="message-bubble">${text}</div>
        `;
    } else {
        messageDiv.innerHTML = `
            <div class="message-bubble">${text}</div>
        `;
    }
    
    demoChatMessages.appendChild(messageDiv);
    demoChatMessages.scrollTop = demoChatMessages.scrollHeight;
}

function getDemoResponse(userMessage) {
    const lowerMsg = userMessage.toLowerCase();
    
    const responses = {
        servizi: 'Offriamo diverse soluzioni AI:<br>• <strong>AI Agent Vocali</strong>: assistenti telefonici 24/7<br>• <strong>AI Agent Testuali</strong>: chatbot e Visual QA<br>• <strong>AI Avatar</strong>: rappresentazioni digitali intelligenti<br>• <strong>E-commerce + AI</strong>: ottimizzazione vendite<br><br>Quale ti interessa approfondire?',
        demo: 'Fantastico! Posso organizzare una demo personalizzata per te. Preferisci:<br>• Una <strong>call di 30 minuti</strong> con il nostro team<br>• Un <strong>test pilota</strong> sul tuo caso d\'uso<br>• Ricevere <strong>documentazione tecnica</strong><br><br>Scrivici su <a href="https://wa.me/393518234567" target="_blank">WhatsApp</a> per programmare!',
        prezzo: 'I nostri prezzi variano in base a:<br>• Volume di interazioni mensili<br>• Complessità dell\'integrazione<br>• Livello di personalizzazione<br>• SLA e supporto richiesto<br><br>Per un preventivo preciso, <a href="contatti.html">contattaci</a> e analizziamo insieme il tuo progetto!',
        avatar: 'Gli <strong>AI Avatar</strong> sono perfetti per:<br>• Reception virtuali<br>• Assistenti e-commerce<br>• Formazione e onboarding<br>• Customer service evoluto<br><br>Vuoi vedere una demo live dell\'avatar?',
        vocale: 'L\'<strong>AI Agent Vocale</strong> può:<br>• Gestire chiamate inbound/outbound<br>• Qualificare lead<br>• Prenotare appuntamenti<br>• Fornire supporto tecnico<br>• Fare up-sell intelligente<br><br>📞 Prova subito: <a href="tel:08119298411">081 1929 8411</a>',
        costo: 'Investire in AI agent ti permette di:<br>• Ridurre costi operativi fino al 60%<br>• Aumentare conversioni del 30-50%<br>• Operare 24/7 senza limiti<br>• Scalare senza assumere<br><br>Il ROI medio dei nostri clienti è del 340% in 6 mesi!',
        'quanto tempo': 'Tempi di implementazione:<br>• <strong>Chatbot semplice</strong>: 1-2 settimane<br>• <strong>AI Agent vocale</strong>: 2-4 settimane<br>• <strong>AI Avatar</strong>: 3-6 settimane<br>• <strong>Integrazione completa</strong>: 1-3 mesi<br><br>Dipende dalla complessità del progetto!',
        integrazione: 'Ci integriamo con:<br>• <strong>CRM</strong>: Salesforce, HubSpot, Pipedrive<br>• <strong>E-commerce</strong>: Shopify, WooCommerce, Magento<br>• <strong>Comunicazione</strong>: Twilio, WhatsApp, Teams<br>• <strong>Custom API</strong>: qualsiasi sistema<br><br>Hai già un sistema in mente?',
        'case study': 'Alcuni risultati dei nostri clienti:<br><br><strong>RetailPro (E-commerce)</strong><br>+128% conversioni, -38% abbandono carrello<br><br><strong>HealthCare Plus</strong><br>-65% costi CS, 99.2% accuracy<br><br><strong>AutoDrive Italia</strong><br>+280% lead qualificati<br><br>Vuoi il case study completo?',
        grazie: 'Prego! 😊 Sono qui per aiutarti. Hai altre domande sui nostri prodotti AI?',
        ciao: 'Ciao! 👋 Benvenuto nella demo di Gaia. Come posso aiutarti? Posso parlarti di servizi, prezzi, integrazioni o case study!',
    };
    
    for (const [keyword, response] of Object.entries(responses)) {
        if (lowerMsg.includes(keyword)) {
            return response;
        }
    }
    
    return 'Interessante! Posso aiutarti con:<br>• Informazioni sui <strong>servizi</strong><br>• <strong>Prezzi</strong> e preventivi<br>• <strong>Integrazioni</strong> tecniche<br>• <strong>Case study</strong> e risultati<br>• Programmazione <strong>demo</strong><br><br>Cosa ti interessa sapere?';
}

function sendDemoMessage() {
    const text = demoChatInput.value.trim();
    if (!text) return;
    
    addDemoMessage(text, 'user');
    demoChatInput.value = '';
    
    // Show typing indicator
    setTimeout(() => {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'chat-message bot typing';
        typingDiv.innerHTML = `
            <div class="message-avatar">
                <div class="avatar-placeholder tiny">G</div>
            </div>
            <div class="message-bubble">Gaia sta scrivendo...</div>
        `;
        demoChatMessages.appendChild(typingDiv);
        demoChatMessages.scrollTop = demoChatMessages.scrollHeight;
        
        setTimeout(() => {
            typingDiv.remove();
            const response = getDemoResponse(text);
            addDemoMessage(response, 'bot');
        }, 1500);
    }, 500);
}

if (demoChatSend) {
    demoChatSend.addEventListener('click', sendDemoMessage);
}

if (demoChatInput) {
    demoChatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendDemoMessage();
        }
    });
}

// Quick action buttons
quickButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        const message = btn.getAttribute('data-message');
        demoChatInput.value = message;
        sendDemoMessage();
    });
});

// ========== IMAGE UPLOAD & ANALYSIS ==========
const uploadArea = document.getElementById('upload-area');
const imageUpload = document.getElementById('image-upload');
const uploadPreview = document.getElementById('upload-preview');
const previewImage = document.getElementById('preview-image');
const analysisResult = document.getElementById('analysis-result');

// Drag and drop handlers
if (uploadArea) {
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = 'var(--digitalizzato-orange)';
        uploadArea.style.background = 'rgba(255, 140, 26, 0.1)';
    });
    
    uploadArea.addEventListener('dragleave', () => {
        uploadArea.style.borderColor = 'var(--digitalizzato-teal)';
        uploadArea.style.background = 'rgba(27, 154, 170, 0.03)';
    });
    
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = 'var(--digitalizzato-teal)';
        uploadArea.style.background = 'rgba(27, 154, 170, 0.03)';
        
        const file = e.dataTransfer.files[0];
        if (file && file.type.startsWith('image/')) {
            handleImageUpload(file);
        } else {
            alert('Per favore, carica un file immagine (JPG, PNG, WEBP)');
        }
    });
    
    uploadArea.addEventListener('click', () => {
        imageUpload.click();
    });
}

if (imageUpload) {
    imageUpload.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            handleImageUpload(file);
        }
    });
}

function handleImageUpload(file) {
    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
        alert('Il file è troppo grande. Dimensione massima: 5MB');
        return;
    }
    
    // Show preview
    const reader = new FileReader();
    reader.onload = (e) => {
        previewImage.src = e.target.result;
        uploadArea.style.display = 'none';
        uploadPreview.hidden = false;
        
        // Simulate AI analysis
        analyzeImage(file.name);
    };
    reader.readAsDataURL(file);
}

function analyzeImage(filename) {
    // Show loading
    analysisResult.innerHTML = `
        <div class="analysis-loading">
            <div class="spinner"></div>
            <p>Analisi in corso...</p>
        </div>
    `;
    
    // Simulate analysis delay
    setTimeout(() => {
        // Generate mock analysis results
        const mockResults = generateMockAnalysis(filename);
        displayAnalysisResults(mockResults);
    }, 2500);
}

function generateMockAnalysis(filename) {
    // Different results based on random scenarios
    const scenarios = [
        {
            object: 'Scarpa da running',
            condition: 'Usata, segni di usura sul tallone',
            recommendations: [
                { name: 'Nike Air Zoom Pegasus 40', match: '95%' },
                { name: 'Asics Gel-Kayano 30', match: '92%' },
                { name: 'Adidas Ultraboost 23', match: '88%' }
            ]
        },
        {
            object: 'Smartphone danneggiato',
            condition: 'Schermo rotto, funzionante',
            recommendations: [
                { name: 'Servizio riparazione schermo', match: '98%' },
                { name: 'iPhone 15 Pro (upgrade)', match: '85%' },
                { name: 'Samsung Galaxy S24', match: '82%' }
            ]
        },
        {
            object: 'Outfit casual',
            condition: 'Jeans e t-shirt bianca',
            recommendations: [
                { name: 'Sneakers bianche minimali', match: '97%' },
                { name: 'Giacca denim', match: '93%' },
                { name: 'Zaino urbano nero', match: '89%' }
            ]
        }
    ];
    
    return scenarios[Math.floor(Math.random() * scenarios.length)];
}

function displayAnalysisResults(results) {
    analysisResult.innerHTML = `
        <div class="analysis-content">
            <h4>✅ Analisi completata</h4>
            
            <div class="analysis-item">
                <strong>Oggetto rilevato:</strong> ${results.object}
            </div>
            
            <div class="analysis-item">
                <strong>Stato:</strong> ${results.condition}
            </div>
            
            <div class="product-recommendations">
                <h4>🎯 Prodotti consigliati dal catalogo</h4>
                <div class="recommendation-grid">
                    ${results.recommendations.map(rec => `
                        <div class="recommendation-item">
                            <div class="rec-placeholder">
                                <i class="ri-shopping-bag-line" style="font-size: 32px; color: var(--digitalizzato-teal);"></i>
                            </div>
                            <strong>${rec.name}</strong>
                            <span style="color: var(--digitalizzato-orange); font-size: 12px;">Match: ${rec.match}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <div style="margin-top: var(--spacing-lg); padding-top: var(--spacing-lg); border-top: 1px solid var(--digitalizzato-grey-light);">
                <button class="btn-primary" style="margin-right: var(--spacing-sm);" onclick="location.reload()">
                    <i class="ri-upload-2-line"></i> Carica altra immagine
                </button>
                <a href="contatti.html" class="btn-secondary">
                    <i class="ri-chat-3-line"></i> Integra Visual QA
                </a>
            </div>
        </div>
    `;
}

// ========== GAIA BUTTON IN PORTFOLIO CTA ==========
const portfolioGaiaBtn = document.getElementById('portfolio-gaia-btn');
if (portfolioGaiaBtn) {
    portfolioGaiaBtn.addEventListener('click', () => {
        const gaiaWindow = document.getElementById('gaia-chat-window');
        if (gaiaWindow) {
            gaiaWindow.hidden = false;
            const gaiaInput = document.getElementById('gaia-input');
            if (gaiaInput) gaiaInput.focus();
        }
    });
}

// ========== SCROLL ANIMATIONS ==========
const observerOptions = {
    threshold: 0.2,
    rootMargin: '0px 0px -100px 0px'
};

const scrollObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Apply to demo sections
document.querySelectorAll('.demo-section').forEach((section, index) => {
    section.style.opacity = '0';
    section.style.transform = 'translateY(30px)';
    section.style.transition = 'all 0.8s ease';
    section.style.transitionDelay = `${index * 0.1}s`;
    scrollObserver.observe(section);
});

// ========== AUTO-GREET IN CHAT AFTER DELAY ==========
setTimeout(() => {
    if (demoChatMessages && demoChatMessages.children.length === 1) {
        addDemoMessage('Prova a chiedermi qualcosa! Ad esempio: "Quali servizi offrite?" oppure usa i pulsanti rapidi qui sotto. 😊', 'bot');
    }
}, 5000);

console.log('%c✨ Portfolio Demo Ready!', 'font-size: 16px; color: #FF8C1A; font-weight: bold;');
console.log('Prova le demo interattive e scopri cosa può fare l\'AI per il tuo business!');