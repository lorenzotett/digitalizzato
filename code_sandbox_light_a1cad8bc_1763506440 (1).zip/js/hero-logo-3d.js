/**
 * Hero Logo 3D Animation
 * Animazione sottile con parallax e perspective per il logo nel hero
 */

(function() {
    'use strict';
    
    const logo3DContainer = document.getElementById('logo-3d');
    if (!logo3DContainer) return;
    
    // Crea l'immagine del logo con effetto 3D
    const logoImg = document.createElement('img');
    logoImg.src = 'https://cdn1.genspark.ai/user-upload-image/rmbg_generated/0_e363610a-6ff6-4a9a-9389-0dca03668db1';
    logoImg.alt = 'Digitalizzato - AI Solutions Agency';
    logoImg.className = 'hero-logo-3d';
    logoImg.setAttribute('width', '320');
    logoImg.setAttribute('height', '80');
    
    logo3DContainer.appendChild(logoImg);
    
    // Animazione parallax sottile al movimento del mouse
    let mouseX = 0;
    let mouseY = 0;
    let currentX = 0;
    let currentY = 0;
    
    // Verifica prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (!prefersReducedMotion) {
        // Mouse movement parallax
        document.addEventListener('mousemove', (e) => {
            const xPercent = (e.clientX / window.innerWidth - 0.5) * 2;
            const yPercent = (e.clientY / window.innerHeight - 0.5) * 2;
            
            mouseX = xPercent * 20; // Max 20px movement
            mouseY = yPercent * 20;
        });
        
        // Smooth animation loop
        function animateLogo() {
            // Easing
            currentX += (mouseX - currentX) * 0.05;
            currentY += (mouseY - currentY) * 0.05;
            
            // Apply transform
            logoImg.style.transform = `
                perspective(1000px)
                translateX(${currentX}px)
                translateY(${currentY}px)
                rotateY(${currentX * 0.5}deg)
                rotateX(${-currentY * 0.5}deg)
                translateZ(30px)
            `;
            
            requestAnimationFrame(animateLogo);
        }
        
        animateLogo();
    } else {
        // Static positioning for reduced motion
        logoImg.style.transform = 'none';
    }
    
    // Scroll reveal animation
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                logoImg.classList.add('revealed');
            }
        });
    }, {
        threshold: 0.2
    });
    
    observer.observe(logo3DContainer);
    
    // Floating animation (subtle)
    if (!prefersReducedMotion) {
        logoImg.style.animation = 'heroLogoFloat 6s ease-in-out infinite';
    }
    
})();

// CSS Keyframes injection
const style = document.createElement('style');
style.textContent = `
    /* Hero Logo 3D Styles */
    .logo-3d-container {
        position: relative;
        width: 100%;
        height: 100%;
        min-height: 350px;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: var(--spacing-2xl);
    }
    
    .hero-logo-3d {
        max-width: 420px;
        width: 100%;
        height: auto;
        opacity: 0;
        transform: perspective(1000px) translateZ(50px) scale(0.9);
        filter: drop-shadow(0 10px 40px rgba(27, 154, 170, 0.3))
                drop-shadow(0 0 60px rgba(255, 140, 26, 0.2));
        transition: opacity 0.8s ease-out,
                    transform 0.8s cubic-bezier(0.34, 1.56, 0.64, 1),
                    filter 0.5s ease;
        will-change: transform, filter;
        backface-visibility: hidden;
        display: block;
        margin: 0 auto;
    }
    
    .hero-logo-3d.revealed {
        opacity: 1;
        transform: perspective(1000px) translateZ(0) scale(1);
    }
    
    .hero-logo-3d:hover {
        filter: drop-shadow(0 15px 50px rgba(27, 154, 170, 0.5))
                drop-shadow(0 0 80px rgba(255, 140, 26, 0.4));
    }
    
    /* Floating animation */
    @keyframes heroLogoFloat {
        0%, 100% {
            transform: perspective(1000px) translateY(0) translateZ(30px);
        }
        50% {
            transform: perspective(1000px) translateY(-10px) translateZ(30px);
        }
    }
    
    /* Responsive */
    @media (max-width: 1023px) {
        .logo-3d-container {
            min-height: 250px;
            padding: var(--spacing-xl);
        }
        
        .hero-logo-3d {
            max-width: 340px;
        }
    }
    
    @media (max-width: 767px) {
        .logo-3d-container {
            min-height: 200px;
            padding: var(--spacing-lg);
        }
        
        .hero-logo-3d {
            max-width: 280px;
        }
    }
    
    @media (max-width: 479px) {
        .logo-3d-container {
            min-height: 180px;
            padding: var(--spacing-md);
        }
        
        .hero-logo-3d {
            max-width: 240px;
        }
    }
    
    /* Accessibility - Reduced Motion */
    @media (prefers-reduced-motion: reduce) {
        .hero-logo-3d {
            animation: none !important;
            transition: opacity 0.3s ease;
        }
        
        .hero-logo-3d.revealed {
            transform: none;
        }
    }
    
    /* High contrast mode */
    @media (prefers-contrast: high) {
        .hero-logo-3d {
            filter: drop-shadow(0 4px 12px rgba(0, 0, 0, 0.6));
        }
    }
`;

document.head.appendChild(style);
