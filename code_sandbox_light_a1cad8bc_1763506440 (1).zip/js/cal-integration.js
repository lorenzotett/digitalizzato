/**
 * CAL.COM INTEGRATION
 * Handles modal and inline embed functionality
 * @version 1.0.0
 */

(function() {
    'use strict';
    
    // Cal.com configuration
    const CAL_CONFIG = {
        username: 'lorenzo-tettine-xqlsqa',
        eventType: 'call-con-lorenzo-team',
        embedId: 'call-con-lorenzo-team'
    };
    
    /**
     * Initialize Cal.com modal functionality
     */
    function initCalModal() {
        const modalTriggers = document.querySelectorAll('[data-cal-modal]');
        
        if (modalTriggers.length === 0) return;
        
        // Create modal if it doesn't exist
        let modal = document.getElementById('cal-modal');
        if (!modal) {
            modal = createModal();
            document.body.appendChild(modal);
        }
        
        // Attach click handlers to all triggers
        modalTriggers.forEach(trigger => {
            trigger.addEventListener('click', (e) => {
                e.preventDefault();
                openCalModal();
            });
        });
        
        // Close modal handlers
        const closeBtn = modal.querySelector('.modal-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', closeCalModal);
        }
        
        // Click outside to close
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeCalModal();
            }
        });
        
        // ESC key to close
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false') {
                closeCalModal();
            }
        });
    }
    
    /**
     * Create modal HTML structure
     */
    function createModal() {
        const modal = document.createElement('div');
        modal.id = 'cal-modal';
        modal.className = 'modal-overlay';
        modal.setAttribute('aria-hidden', 'true');
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-labelledby', 'cal-modal-title');
        modal.setAttribute('aria-modal', 'true');
        
        modal.innerHTML = `
            <div class="modal-container">
                <div class="modal-header">
                    <h2 id="cal-modal-title" class="modal-title">Prenota un meeting</h2>
                    <button class="modal-close" aria-label="Chiudi modal">
                        <i class="ri-close-line"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="cal-modal-embed" style="width:100%; height:100%; overflow:scroll;"></div>
                </div>
            </div>
        `;
        
        return modal;
    }
    
    /**
     * Open Cal.com modal
     */
    function openCalModal() {
        const modal = document.getElementById('cal-modal');
        if (!modal) return;
        
        // Set aria-hidden to false
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('modal-open');
        
        // Initialize Cal.com embed if not already loaded
        const embedContainer = document.getElementById('cal-modal-embed');
        if (embedContainer && !embedContainer.hasAttribute('data-cal-loaded')) {
            loadCalEmbed('cal-modal-embed');
            embedContainer.setAttribute('data-cal-loaded', 'true');
        }
        
        // Focus trap
        trapFocus(modal);
        
        // Announce to screen readers
        announceToScreenReader('Modal aperto: Prenota un meeting');
    }
    
    /**
     * Close Cal.com modal
     */
    function closeCalModal() {
        const modal = document.getElementById('cal-modal');
        if (!modal) return;
        
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('modal-open');
        
        // Return focus to trigger button
        const lastFocusedElement = document.activeElement;
        if (lastFocusedElement) {
            lastFocusedElement.blur();
        }
        
        announceToScreenReader('Modal chiuso');
    }
    
    /**
     * Load Cal.com embed script
     */
    function loadCalEmbed(containerId) {
        if (typeof Cal === 'undefined') {
            // Load Cal.com embed script
            const script = document.createElement('script');
            script.src = 'https://app.cal.com/embed/embed.js';
            script.async = true;
            script.onload = () => {
                initializeCalEmbed(containerId);
            };
            document.head.appendChild(script);
        } else {
            initializeCalEmbed(containerId);
        }
    }
    
    /**
     * Initialize Cal.com embed
     */
    function initializeCalEmbed(containerId) {
        if (typeof Cal === 'undefined') {
            console.error('Cal.com embed script not loaded');
            return;
        }
        
        Cal("init", CAL_CONFIG.embedId, {
            origin: "https://app.cal.com"
        });
        
        Cal.ns[CAL_CONFIG.embedId]("inline", {
            elementOrSelector: `#${containerId}`,
            config: {"layout": "month_view"},
            calLink: `${CAL_CONFIG.username}/${CAL_CONFIG.eventType}`
        });
        
        Cal.ns[CAL_CONFIG.embedId]("ui", {
            "hideEventTypeDetails": false,
            "layout": "month_view"
        });
    }
    
    /**
     * Initialize inline Cal.com embeds
     */
    function initCalInline() {
        const inlineContainers = document.querySelectorAll('[data-cal-inline]');
        
        inlineContainers.forEach(container => {
            const containerId = container.id;
            if (containerId) {
                loadCalEmbed(containerId);
            }
        });
    }
    
    /**
     * Focus trap for modal accessibility
     */
    function trapFocus(modal) {
        const focusableElements = modal.querySelectorAll(
            'a[href], button:not([disabled]), textarea:not([disabled]), ' +
            'input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        
        if (focusableElements.length === 0) return;
        
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];
        
        // Focus first element
        setTimeout(() => {
            firstElement.focus();
        }, 100);
        
        // Trap focus within modal
        modal.addEventListener('keydown', (e) => {
            if (e.key !== 'Tab') return;
            
            if (e.shiftKey) {
                if (document.activeElement === firstElement) {
                    e.preventDefault();
                    lastElement.focus();
                }
            } else {
                if (document.activeElement === lastElement) {
                    e.preventDefault();
                    firstElement.focus();
                }
            }
        });
    }
    
    /**
     * Announce to screen readers
     */
    function announceToScreenReader(message) {
        const announcement = document.createElement('div');
        announcement.setAttribute('role', 'status');
        announcement.setAttribute('aria-live', 'polite');
        announcement.className = 'sr-only';
        announcement.textContent = message;
        
        document.body.appendChild(announcement);
        
        setTimeout(() => {
            document.body.removeChild(announcement);
        }, 1000);
    }
    
    /**
     * Initialize on DOM ready
     */
    function init() {
        initCalModal();
        initCalInline();
        
        console.log('✅ Cal.com integration initialized');
    }
    
    // Run on DOMContentLoaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    // Expose public API
    window.CalIntegration = {
        openModal: openCalModal,
        closeModal: closeCalModal,
        loadEmbed: loadCalEmbed
    };
    
})();

/**
 * Screen reader only utility class
 */
const style = document.createElement('style');
style.textContent = `
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border-width: 0;
    }
`;
document.head.appendChild(style);
