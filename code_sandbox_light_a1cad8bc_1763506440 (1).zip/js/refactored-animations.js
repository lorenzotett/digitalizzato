/* ====================================
   REFACTORED ANIMATIONS
   - Scroll Reveal (IntersectionObserver)
   - Mobile Menu Toggle
   - Smooth Scroll with Header Offset
   ==================================== */

// Check for reduced motion preference
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ============ SCROLL REVEAL ANIMATIONS ============ */
function initScrollReveal() {
  if (prefersReducedMotion) return; // Respect accessibility preference
  
  // Elements to animate on scroll
  const revealElements = document.querySelectorAll('.metric, .story, .hero__visual .mock, .cal-block');
  
  if (revealElements.length === 0) return;
  
  // Add initial hidden state
  revealElements.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
  });
  
  // IntersectionObserver configuration
  const observerOptions = {
    root: null,
    threshold: 0.2, // Trigger when 20% visible
    rootMargin: '0px'
  };
  
  // Observer callback
  const observerCallback = (entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        // Add 'in' class and reset transform
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        entry.target.classList.add('in');
        
        // Stop observing once revealed (performance optimization)
        observer.unobserve(entry.target);
      }
    });
  };
  
  // Create and attach observer
  const observer = new IntersectionObserver(observerCallback, observerOptions);
  
  revealElements.forEach(el => observer.observe(el));
}

/* ============ MOBILE MENU TOGGLE ============ */
function initMobileMenu() {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav');
  const navLinks = document.querySelectorAll('.nav a');
  
  if (!navToggle || !nav) return;
  
  // Toggle menu on button click
  navToggle.addEventListener('click', () => {
    const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
    
    navToggle.setAttribute('aria-expanded', !isExpanded);
    nav.classList.toggle('active');
    
    // Update icon
    const icon = navToggle.querySelector('i') || navToggle;
    if (nav.classList.contains('active')) {
      icon.textContent = '✕'; // Close icon
      // Prevent body scroll when menu open
      document.body.style.overflow = 'hidden';
    } else {
      icon.textContent = '☰'; // Hamburger icon
      document.body.style.overflow = '';
    }
  });
  
  // Close menu when clicking a link
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      nav.classList.remove('active');
      navToggle.setAttribute('aria-expanded', 'false');
      const icon = navToggle.querySelector('i') || navToggle;
      icon.textContent = '☰';
      document.body.style.overflow = '';
    });
  });
  
  // Close menu on ESC key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && nav.classList.contains('active')) {
      nav.classList.remove('active');
      navToggle.setAttribute('aria-expanded', 'false');
      const icon = navToggle.querySelector('i') || navToggle;
      icon.textContent = '☰';
      document.body.style.overflow = '';
      navToggle.focus(); // Return focus to toggle button
    }
  });
  
  // Close menu when clicking outside
  document.addEventListener('click', (e) => {
    if (nav.classList.contains('active') && 
        !nav.contains(e.target) && 
        !navToggle.contains(e.target)) {
      nav.classList.remove('active');
      navToggle.setAttribute('aria-expanded', 'false');
      const icon = navToggle.querySelector('i') || navToggle;
      icon.textContent = '☰';
      document.body.style.overflow = '';
    }
  });
}

/* ============ SMOOTH SCROLL WITH OFFSET ============ */
function initSmoothScroll() {
  // Get all anchor links
  const anchorLinks = document.querySelectorAll('a[href^="#"]');
  
  anchorLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      const href = this.getAttribute('href');
      
      // Ignore if href is just "#" or empty
      if (href === '#' || href === '') return;
      
      const target = document.querySelector(href);
      
      if (target) {
        e.preventDefault();
        
        // Calculate offset (header height + small buffer)
        const headerHeight = document.querySelector('.site-header')?.offsetHeight || 72;
        const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - headerHeight - 20;
        
        // Smooth scroll
        window.scrollTo({
          top: targetPosition,
          behavior: prefersReducedMotion ? 'auto' : 'smooth'
        });
        
        // Update URL without jumping
        if (history.pushState) {
          history.pushState(null, null, href);
        }
        
        // Focus target for accessibility
        target.setAttribute('tabindex', '-1');
        target.focus();
      }
    });
  });
}

/* ============ ACTIVE NAV LINK HIGHLIGHTING ============ */
function initActiveNavLinks() {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav a[href^="#"]');
  
  if (sections.length === 0 || navLinks.length === 0) return;
  
  const observerOptions = {
    root: null,
    threshold: 0.3, // Section is "active" when 30% visible
    rootMargin: '-80px 0px 0px 0px' // Account for fixed header
  };
  
  const observerCallback = (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        
        // Remove active class from all links
        navLinks.forEach(link => link.classList.remove('active'));
        
        // Add active class to matching link
        const activeLink = document.querySelector(`.nav a[href="#${id}"]`);
        if (activeLink) {
          activeLink.classList.add('active');
        }
      }
    });
  };
  
  const observer = new IntersectionObserver(observerCallback, observerOptions);
  sections.forEach(section => observer.observe(section));
}

/* ============ INITIALIZE ON DOM READY ============ */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

function init() {
  initScrollReveal();
  initMobileMenu();
  initSmoothScroll();
  initActiveNavLinks();
  
  console.log('✅ Refactored animations initialized');
}

// Re-initialize on page show (for bfcache)
window.addEventListener('pageshow', (event) => {
  if (event.persisted) {
    init();
  }
});
