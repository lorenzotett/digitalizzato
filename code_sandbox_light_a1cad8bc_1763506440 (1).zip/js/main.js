// Main JavaScript for Digitalizzato Website

// ========== HEADER SCROLL BEHAVIOR ==========
const header = document.getElementById('header');
let lastScroll = 0;

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 100) {
        header.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.12)';
    } else {
        header.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.08)';
    }
    
    lastScroll = currentScroll;
});

// ========== MOBILE MENU TOGGLE ==========
const mobileToggle = document.getElementById('mobile-toggle');
const nav = document.getElementById('nav-menu');

if (mobileToggle) {
    mobileToggle.addEventListener('click', () => {
        nav.classList.toggle('active');
        const icon = mobileToggle.querySelector('i');
        
        if (nav.classList.contains('active')) {
            icon.classList.remove('ri-menu-line');
            icon.classList.add('ri-close-line');
        } else {
            icon.classList.remove('ri-close-line');
            icon.classList.add('ri-menu-line');
        }
    });
}

// ========== VANILLA TILT INIT ==========
if (typeof VanillaTilt !== 'undefined') {
    VanillaTilt.init(document.querySelectorAll("[data-tilt]"), {
        max: 8,
        speed: 400,
        glare: true,
        "max-glare": 0.2,
    });
}

// ========== INTERSECTION OBSERVER FOR ANIMATIONS ==========
const observerOptions = {
    threshold: 0.2,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, observerOptions);

// Observe all animated elements
document.querySelectorAll('.card-service, .nicchia-card, .cta-box').forEach(el => {
    observer.observe(el);
});

// ========== COUNTERS ANIMATION ==========
const counters = document.querySelectorAll('.counter');

const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const counter = entry.target;
            const target = parseInt(counter.getAttribute('data-target'));
            const duration = 2000;
            const increment = target / (duration / 16);
            let current = 0;
            
            const updateCounter = () => {
                current += increment;
                if (current < target) {
                    counter.innerText = Math.ceil(current);
                    requestAnimationFrame(updateCounter);
                } else {
                    counter.innerText = target;
                }
            };
            
            updateCounter();
            counterObserver.unobserve(counter);
        }
    });
}, { threshold: 0.5 });

counters.forEach(counter => {
    counterObserver.observe(counter);
});

// ========== NICCHIE CAROUSEL ==========
const nicchieCarousel = document.getElementById('nicchie-carousel');
const prevBtn = document.getElementById('nicchie-prev');
const nextBtn = document.getElementById('nicchie-next');

if (nicchieCarousel && prevBtn && nextBtn) {
    let currentIndex = 0;
    const cards = nicchieCarousel.querySelectorAll('.nicchia-card');
    const cardWidth = cards[0]?.offsetWidth + 32 || 0; // card width + gap
    
    prevBtn.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
            nicchieCarousel.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
        }
    });
    
    nextBtn.addEventListener('click', () => {
        if (currentIndex < cards.length - 1) {
            currentIndex++;
            nicchieCarousel.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
        }
    });
}

// ========== GAIA WIDGET LOGIC ==========
const gaiaToggle = document.getElementById('gaia-toggle');
const gaiaWindow = document.getElementById('gaia-chat-window');
const gaiaClose = document.getElementById('gaia-close');
const gaiaInput = document.getElementById('gaia-input');
const gaiaSend = document.getElementById('gaia-send');
const gaiaMessages = document.getElementById('gaia-messages');

// Open Gaia from various CTA buttons
const gaiaButtons = [
    document.getElementById('open-gaia'),
    document.getElementById('hero-gaia-btn'),
    document.getElementById('footer-gaia-btn')
];

gaiaButtons.forEach(btn => {
    if (btn) {
        btn.addEventListener('click', () => {
            gaiaWindow.hidden = false;
            gaiaInput.focus();
        });
    }
});

// Toggle chat window
if (gaiaToggle) {
    gaiaToggle.addEventListener('click', () => {
        gaiaWindow.hidden = false;
        gaiaInput.focus();
    });
}

// Close chat window
if (gaiaClose) {
    gaiaClose.addEventListener('click', () => {
        gaiaWindow.hidden = true;
    });
}

// Send message function
function sendMessage() {
    const text = gaiaInput.value.trim();
    if (!text) return;
    
    // Add user message
    addMessage(text, 'user');
    gaiaInput.value = '';
    
    // Show typing indicator
    showTypingIndicator();
    
    // Simulate AI response
    setTimeout(() => {
        removeTypingIndicator();
        const response = getGaiaResponse(text);
        addMessage(response, 'bot');
    }, 1000);
}

function addMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `gaia-message gaia-message-${sender}`;
    
    if (sender === 'bot') {
        messageDiv.innerHTML = `
            <div class="message-avatar">
                <div class="avatar-placeholder tiny">G</div>
            </div>
            <div class="message-content">
                <p>${text}</p>
            </div>
        `;
    } else {
        messageDiv.innerHTML = `
            <div class="message-content">
                <p>${text}</p>
            </div>
        `;
    }
    
    gaiaMessages.appendChild(messageDiv);
    gaiaMessages.scrollTop = gaiaMessages.scrollHeight;
}

function showTypingIndicator() {
    const typingDiv = document.createElement('div');
    typingDiv.className = 'gaia-message gaia-message-bot typing-indicator';
    typingDiv.innerHTML = `
        <div class="message-avatar">
            <div class="avatar-placeholder tiny">G</div>
        </div>
        <div class="message-content">
            <p>Gaia sta scrivendo...</p>
        </div>
    `;
    gaiaMessages.appendChild(typingDiv);
    gaiaMessages.scrollTop = gaiaMessages.scrollHeight;
}

function removeTypingIndicator() {
    const indicator = gaiaMessages.querySelector('.typing-indicator');
    if (indicator) {
        indicator.remove();
    }
}

function getGaiaResponse(userMessage) {
    const lowerMsg = userMessage.toLowerCase();
    
    // Response patterns
    const responses = {
        servizi: 'Offriamo AI Agent Vocali, Testuali, Avatar, E-commerce+AI, sviluppo SaaS e molto altro. Quale servizio ti interessa approfondire?',
        prezzi: 'I nostri prezzi dipendono dal progetto specifico. Vuoi ricevere una demo personalizzata gratuita per discutere il tuo caso?',
        demo: 'Perfetto! Puoi <a href="portfolio.html">testare i nostri prodotti nel Portfolio</a> oppure <a href="contatti.html">prenotare una demo personalizzata</a>. Cosa preferisci?',
        avatar: 'Gli AI Avatar sono rappresentazioni digitali connesse alla tua knowledge base. Possono parlare, rispondere a domande e guidare i clienti. Vuoi vedere una demo?',
        vocale: 'Gli AI Agent Vocali gestiscono chiamate inbound e outbound 24/7. Perfetti per customer service, sales e supporto tecnico. Posso mostrarti un caso d\'uso?',
        ecommerce: 'Per l\'e-commerce offriamo chatbot intelligenti, visual QA che analizza foto prodotti, up-sell automatico e recupero carrelli. Interessante?',
        contatti: 'Puoi contattarci via <a href="https://wa.me/393518234567" target="_blank">WhatsApp</a>, <a href="tel:+393518234567">telefono</a> o compilando il <a href="contatti.html">form contatti</a>. Rispondiamo entro 2 ore!',
        portfolio: 'Nel <a href="portfolio.html">Portfolio</a> puoi testare dal vivo i nostri prodotti: chatbot Gaia, avatar AI e visual QA. Vai a provare!',
        coverly: 'Coverly è il nostro SaaS proprietario in fase di lancio negli USA. Una piattaforma per automazione intelligente, integrazioni e analytics. <a href="coverly.html">Scopri di più</a>!',
        nicchie: 'Lavoriamo con diversi settori: Retail, Healthcare, Real Estate, Automotive, Hospitality, Finance e altro. Quale settore ti interessa?',
        partner: 'Collaboriamo con The Partners, una rete di eccellenze italiane. Se vuoi diventare partner, <a href="partner.html">scopri come</a>!',
        ciao: 'Ciao! 👋 Come posso aiutarti oggi? Posso darti informazioni su servizi, casi d\'uso, prezzi o metterti in contatto con il team.',
        grazie: 'Prego! Sono qui per aiutarti. Hai altre domande?'
    };
    
    // Check for keywords
    for (const [keyword, response] of Object.entries(responses)) {
        if (lowerMsg.includes(keyword)) {
            return response;
        }
    }
    
    // Default response
    return 'Interessante! Posso aiutarti con informazioni su <strong>servizi</strong>, <strong>casi d\'uso</strong>, <strong>prezzi</strong>, oppure metterti in contatto con il team. Cosa preferisci sapere?';
}

// Send message on button click
if (gaiaSend) {
    gaiaSend.addEventListener('click', sendMessage);
}

// Send message on Enter key
if (gaiaInput) {
    gaiaInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
}

// ========== SMOOTH SCROLL ==========
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// ========== LOGO 3D ANIMATION ==========
const logo3DContainer = document.getElementById('logo-3d');

if (logo3DContainer) {
    // Create animated logo placeholder
    const logoElement = document.createElement('div');
    logoElement.className = 'animated-logo';
    logoElement.style.cssText = `
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        animation: rotate3d 10s ease-in-out infinite;
    `;
    
    const logoImg = document.createElement('img');
    logoImg.src = 'https://page.gensparksite.com/v1/base64_upload/8c53564712c135cab8789fcc8d237178';
    logoImg.alt = 'Digitalizzato Logo';
    logoImg.style.cssText = `
        max-width: 100%;
        max-height: 100%;
        filter: drop-shadow(0 10px 30px rgba(27, 154, 170, 0.3));
    `;
    
    logoElement.appendChild(logoImg);
    logo3DContainer.appendChild(logoElement);
    
    // Add 3D rotation animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes rotate3d {
            0%, 100% {
                transform: perspective(1000px) rotateY(0deg) rotateX(0deg);
            }
            25% {
                transform: perspective(1000px) rotateY(10deg) rotateX(5deg);
            }
            50% {
                transform: perspective(1000px) rotateY(0deg) rotateX(10deg);
            }
            75% {
                transform: perspective(1000px) rotateY(-10deg) rotateX(5deg);
            }
        }
    `;
    document.head.appendChild(style);
}

// ========== FORM VALIDATION ==========
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Basic validation
        const requiredFields = form.querySelectorAll('[required]');
        let isValid = true;
        
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                field.style.borderColor = 'var(--digitalizzato-orange)';
            } else {
                field.style.borderColor = '';
            }
        });
        
        if (isValid) {
            // Show success message
            alert('Grazie! Ti contatteremo presto.');
            form.reset();
        } else {
            alert('Per favore, compila tutti i campi obbligatori.');
        }
    });
});

// ========== CONSOLE EASTER EGG ==========
console.log(`
%c🤖 Digitalizzato - AI Solutions Agency
%cL'intelligenza artificiale che lavora per te.

Interessato a come abbiamo costruito questo sito?
Contattaci: info@digitalizzato.it
`, 
'font-size: 20px; font-weight: bold; color: #FF8C1A;',
'font-size: 14px; color: #1A4D2E;'
);

// ========== PAGE LOAD ANIMATION ==========
window.addEventListener('load', () => {
    document.body.classList.add('loaded');
    
    // Trigger animations
    setTimeout(() => {
        document.querySelectorAll('.animate-in').forEach((el, index) => {
            setTimeout(() => {
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }, 300);
});