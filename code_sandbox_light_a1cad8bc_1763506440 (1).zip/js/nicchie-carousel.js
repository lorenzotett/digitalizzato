/**
 * Nicchie Carousel - Fluid and responsive carousel
 * Features: Drag, swipe, arrow keys, pagination
 */

(function() {
    'use strict';
    
    const carousel = document.getElementById('nicchie-carousel');
    const prevBtn = document.getElementById('nicchie-prev');
    const nextBtn = document.getElementById('nicchie-next');
    
    if (!carousel || !prevBtn || !nextBtn) return;
    
    const cards = Array.from(carousel.querySelectorAll('.nicchia-card'));
    const cardWidth = cards[0]?.offsetWidth || 380;
    const gap = 32; // Spacing between cards
    
    let currentIndex = 0;
    let isDragging = false;
    let startX = 0;
    let currentX = 0;
    let scrollStart = 0;
    
    // Create pagination dots
    const paginationContainer = document.createElement('div');
    paginationContainer.className = 'carousel-pagination';
    carousel.parentElement.appendChild(paginationContainer);
    
    cards.forEach((_, index) => {
        const dot = document.createElement('button');
        dot.className = 'carousel-dot';
        dot.setAttribute('aria-label', `Vai al settore ${index + 1}`);
        if (index === 0) dot.classList.add('active');
        dot.addEventListener('click', () => scrollToIndex(index));
        paginationContainer.appendChild(dot);
    });
    
    const dots = Array.from(paginationContainer.querySelectorAll('.carousel-dot'));
    
    // Update active dot
    function updateDots(index) {
        dots.forEach((dot, i) => {
            dot.classList.toggle('active', i === index);
        });
    }
    
    // Scroll to specific index
    function scrollToIndex(index) {
        if (index < 0 || index >= cards.length) return;
        
        currentIndex = index;
        const scrollPosition = (cardWidth + gap) * index;
        carousel.scrollTo({
            left: scrollPosition,
            behavior: 'smooth'
        });
        
        updateDots(index);
        updateButtons();
    }
    
    // Update button states
    function updateButtons() {
        prevBtn.disabled = currentIndex === 0;
        nextBtn.disabled = currentIndex === cards.length - 1;
    }
    
    // Previous slide
    prevBtn.addEventListener('click', () => {
        if (currentIndex > 0) {
            scrollToIndex(currentIndex - 1);
        }
    });
    
    // Next slide
    nextBtn.addEventListener('click', () => {
        if (currentIndex < cards.length - 1) {
            scrollToIndex(currentIndex + 1);
        }
    });
    
    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            prevBtn.click();
        } else if (e.key === 'ArrowRight') {
            nextBtn.click();
        }
    });
    
    // Drag/swipe functionality
    carousel.addEventListener('mousedown', startDragging);
    carousel.addEventListener('touchstart', startDragging, { passive: true });
    
    carousel.addEventListener('mousemove', drag);
    carousel.addEventListener('touchmove', drag, { passive: true });
    
    carousel.addEventListener('mouseup', stopDragging);
    carousel.addEventListener('mouseleave', stopDragging);
    carousel.addEventListener('touchend', stopDragging);
    
    function startDragging(e) {
        isDragging = true;
        carousel.style.cursor = 'grabbing';
        carousel.style.userSelect = 'none';
        
        startX = e.type.includes('mouse') ? e.pageX : e.touches[0].pageX;
        scrollStart = carousel.scrollLeft;
    }
    
    function drag(e) {
        if (!isDragging) return;
        
        e.preventDefault();
        currentX = e.type.includes('mouse') ? e.pageX : e.touches[0].pageX;
        const diff = startX - currentX;
        carousel.scrollLeft = scrollStart + diff;
    }
    
    function stopDragging() {
        if (!isDragging) return;
        
        isDragging = false;
        carousel.style.cursor = 'grab';
        carousel.style.userSelect = 'auto';
        
        // Snap to nearest card
        const scrolled = carousel.scrollLeft;
        const nearestIndex = Math.round(scrolled / (cardWidth + gap));
        scrollToIndex(nearestIndex);
    }
    
    // Detect scroll position to update current index
    let scrollTimeout;
    carousel.addEventListener('scroll', () => {
        clearTimeout(scrollTimeout);
        
        scrollTimeout = setTimeout(() => {
            const scrolled = carousel.scrollLeft;
            const index = Math.round(scrolled / (cardWidth + gap));
            
            if (index !== currentIndex) {
                currentIndex = index;
                updateDots(index);
                updateButtons();
            }
        }, 100);
    });
    
    // Resize handler
    let resizeTimeout;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimeout);
        
        resizeTimeout = setTimeout(() => {
            const newCardWidth = cards[0]?.offsetWidth || 380;
            scrollToIndex(currentIndex); // Recalculate position
        }, 250);
    });
    
    // Initialize
    updateButtons();
    carousel.style.cursor = 'grab';
    
    // Add emoji data attributes
    const emojis = ['🛒', '❤️', '🏠', '🚗', '🏨', '💼', '📚', '🏦'];
    cards.forEach((card, index) => {
        if (index < emojis.length) {
            card.setAttribute('data-emoji', emojis[index]);
        }
    });
    
})();
