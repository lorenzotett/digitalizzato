// Partner Page JavaScript

// ========== SCROLL REVEAL ANIMATION ==========
const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
        if (entry.isIntersecting) {
            setTimeout(() => {
                entry.target.classList.add('reveal-in');
            }, index * 100); // Stagger effect
            revealObserver.unobserve(entry.target);
        }
    });
}, {
    threshold: 0.15,
    rootMargin: '0px 0px -50px 0px'
});

// Observe all partner cards
document.querySelectorAll('.partner-card.reveal').forEach(card => {
    revealObserver.observe(card);
});

// ========== 3D TILT EFFECT ON PARTNER CARDS ==========
document.querySelectorAll('.partner-card').forEach(card => {
    card.addEventListener('pointermove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        
        const rotateX = ((y - centerY) / centerY) * -8; // Max 8deg
        const rotateY = ((x - centerX) / centerX) * 8;
        
        card.style.transform = `
            perspective(1000px) 
            rotateX(${rotateX}deg) 
            rotateY(${rotateY}deg) 
            translateY(-12px) 
            translateZ(20px)
            scale(1.02)
        `;
    });
    
    card.addEventListener('pointerleave', () => {
        card.style.transform = '';
    });
});

// Disable 3D effects on mobile/touch devices
if ('ontouchstart' in window) {
    document.querySelectorAll('.partner-card').forEach(card => {
        card.style.transform = '';
        card.addEventListener('touchstart', () => {
            card.classList.add('active');
        });
        card.addEventListener('touchend', () => {
            setTimeout(() => card.classList.remove('active'), 300);
        });
    });
}

// ========== PARTNER FORM HANDLING ==========
const partnerForm = document.getElementById('partner-form');

if (partnerForm) {
    partnerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(partnerForm);
        const data = Object.fromEntries(formData);
        
        // Validate required fields
        const requiredFields = ['company', 'email', 'sector', 'message'];
        let isValid = true;
        
        requiredFields.forEach(field => {
            const input = partnerForm.querySelector(`[name="${field}"]`);
            if (!input.value.trim()) {
                isValid = false;
                input.style.borderColor = 'var(--brand-orange)';
            } else {
                input.style.borderColor = '';
            }
        });
        
        if (!isValid) {
            alert('Per favore, compila tutti i campi obbligatori (*)');
            return;
        }
        
        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(data.email)) {
            alert('Per favore, inserisci un indirizzo email valido.');
            return;
        }
        
        // Show success message
        alert('✅ Grazie per il tuo interesse!\n\nLa tua candidatura è stata inviata con successo.\nTi contatteremo entro 48 ore lavorative per valutare la partnership.');
        
        // Reset form
        partnerForm.reset();
        
        // In production: send data to server/CRM
        console.log('Partner Form Data:', data);
        
        // Example API call (uncomment in production):
        /*
        fetch('/api/partner-request', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(result => {
            console.log('Success:', result);
            // Show success modal or redirect
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Si è verificato un errore. Riprova più tardi o contattaci direttamente.');
        });
        */
    });
}

// ========== PARTNERS COUNT ANIMATION ==========
function animatePartnerCount() {
    const partnersCount = document.querySelectorAll('.partner-card').length;
    const countElement = document.querySelector('.partners-count');
    
    if (countElement) {
        let count = 0;
        const duration = 2000;
        const increment = partnersCount / (duration / 16);
        
        const counter = setInterval(() => {
            count += increment;
            if (count >= partnersCount) {
                countElement.textContent = partnersCount;
                clearInterval(counter);
            } else {
                countElement.textContent = Math.floor(count);
            }
        }, 16);
    }
}

// Trigger count animation when visible
const countObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            animatePartnerCount();
            countObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.5 });

const partnersSection = document.querySelector('.partners-section');
if (partnersSection) {
    countObserver.observe(partnersSection);
}

// ========== FEATURED PARTNER HIGHLIGHT ==========
const featuredCard = document.querySelector('.partner-card.featured');

if (featuredCard) {
    // Add pulse animation to featured badge
    setInterval(() => {
        const badge = featuredCard.querySelector('.featured-badge');
        if (badge) {
            badge.style.transform = 'scale(1.1)';
            setTimeout(() => {
                badge.style.transform = 'scale(1)';
            }, 200);
        }
    }, 3000);
}

// ========== KEYBOARD NAVIGATION FOR PARTNER CARDS ==========
document.querySelectorAll('.partner-card').forEach((card, index) => {
    card.setAttribute('tabindex', '0');
    card.setAttribute('role', 'article');
    
    card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            // Trigger hover effect or navigate
            card.click();
        }
    });
});

// ========== ACCESSIBILITY: FOCUS VISIBLE ==========
document.querySelectorAll('.partner-card').forEach(card => {
    card.addEventListener('focus', () => {
        card.style.outline = '3px solid var(--brand-orange)';
        card.style.outlineOffset = '4px';
    });
    
    card.addEventListener('blur', () => {
        card.style.outline = '';
        card.style.outlineOffset = '';
    });
});

// ========== DISABLE ANIMATIONS FOR REDUCED MOTION ==========
if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.querySelectorAll('.partner-card, .benefit-card, .reveal').forEach(el => {
        el.style.transition = 'none';
        el.style.animation = 'none';
    });
}

console.log('✨ Partner Page Loaded!');
console.log(`Found ${document.querySelectorAll('.partner-card').length} partners in the network.`);