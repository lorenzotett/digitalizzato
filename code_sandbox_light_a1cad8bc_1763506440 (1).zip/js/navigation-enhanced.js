/**
 * ENHANCED NAVIGATION
 * Gestisce menu mobile, scroll behavior, active states
 * @version 2.0.0
 */

(function() {
    'use strict';
    
    // ===== CONFIGURATION =====
    const CONFIG = {
        headerSelector: '.header',
        mobileToggleSelector: '.mobile-toggle',
        navSelector: '.nav',
        navLinkSelector: '.nav-link',
        scrollThreshold: 100,
        headerHeight: 72
    };
    
    // ===== STATE =====
    let state = {
        mobileMenuOpen: false,
        currentScrollY: 0,
        lastScrollY: 0
    };
    
    // ===== ELEMENTS =====
    const elements = {
        header: null,
        mobileToggle: null,
        nav: null,
        navLinks: []
    };
    
    /**
     * Initialize all navigation features
     */
    function init() {
        // Get DOM elements
        elements.header = document.querySelector(CONFIG.headerSelector);
        elements.mobileToggle = document.querySelector(CONFIG.mobileToggleSelector);
        elements.nav = document.querySelector(CONFIG.navSelector);
        elements.navLinks = Array.from(document.querySelectorAll(CONFIG.navLinkSelector));
        
        if (!elements.header) {
            console.warn('Header element not found');
            return;
        }
        
        // Setup event listeners
        setupScrollBehavior();
        setupMobileMenu();
        setupSmoothScroll();
        setupActiveLinks();
        setupClickOutside();
        
        console.log('✅ Enhanced Navigation initialized');
    }
    
    /**
     * Setup scroll behavior - shrink header, hide/show
     */
    function setupScrollBehavior() {
        let ticking = false;
        
        window.addEventListener('scroll', () => {
            state.lastScrollY = state.currentScrollY;
            state.currentScrollY = window.scrollY;
            
            if (!ticking) {
                window.requestAnimationFrame(() => {
                    handleScroll();
                    ticking = false;
                });
                ticking = true;
            }
        });
        
        // Initial check
        handleScroll();
    }
    
    /**
     * Handle scroll changes
     */
    function handleScroll() {
        const scrollY = state.currentScrollY;
        
        // Add "scrolled" class after threshold
        if (scrollY > CONFIG.scrollThreshold) {
            elements.header.classList.add('scrolled');
        } else {
            elements.header.classList.remove('scrolled');
        }
        
        // Hide header on scroll down, show on scroll up (optional)
        // Uncomment to enable:
        /*
        const scrollingDown = scrollY > state.lastScrollY;
        
        if (scrollingDown && scrollY > CONFIG.scrollThreshold * 2) {
            elements.header.style.transform = 'translateY(-100%)';
        } else {
            elements.header.style.transform = 'translateY(0)';
        }
        */
    }
    
    /**
     * Setup mobile menu toggle
     */
    function setupMobileMenu() {
        if (!elements.mobileToggle || !elements.nav) return;
        
        elements.mobileToggle.addEventListener('click', toggleMobileMenu);
        
        // Close menu when clicking nav link
        elements.navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth <= 1023) {
                    closeMobileMenu();
                }
            });
        });
        
        // Close menu on window resize (desktop)
        window.addEventListener('resize', debounce(() => {
            if (window.innerWidth > 1023 && state.mobileMenuOpen) {
                closeMobileMenu();
            }
        }, 250));
    }
    
    /**
     * Toggle mobile menu open/close
     */
    function toggleMobileMenu() {
        if (state.mobileMenuOpen) {
            closeMobileMenu();
        } else {
            openMobileMenu();
        }
    }
    
    /**
     * Open mobile menu
     */
    function openMobileMenu() {
        state.mobileMenuOpen = true;
        elements.nav.classList.add('active');
        elements.mobileToggle.classList.add('active');
        elements.mobileToggle.setAttribute('aria-expanded', 'true');
        elements.mobileToggle.setAttribute('aria-label', 'Chiudi menu');
        
        // Change icon
        const icon = elements.mobileToggle.querySelector('i');
        if (icon) {
            icon.className = 'ri-close-line';
        }
        
        // Prevent body scroll
        document.body.style.overflow = 'hidden';
        
        // Announce to screen readers
        announceToScreenReader('Menu aperto');
    }
    
    /**
     * Close mobile menu
     */
    function closeMobileMenu() {
        state.mobileMenuOpen = false;
        elements.nav.classList.remove('active');
        elements.mobileToggle.classList.remove('active');
        elements.mobileToggle.setAttribute('aria-expanded', 'false');
        elements.mobileToggle.setAttribute('aria-label', 'Apri menu');
        
        // Change icon back
        const icon = elements.mobileToggle.querySelector('i');
        if (icon) {
            icon.className = 'ri-menu-line';
        }
        
        // Re-enable body scroll
        document.body.style.overflow = '';
        
        // Announce to screen readers
        announceToScreenReader('Menu chiuso');
    }
    
    /**
     * Setup click outside to close menu
     */
    function setupClickOutside() {
        document.addEventListener('click', (e) => {
            if (!state.mobileMenuOpen) return;
            
            const isClickInsideNav = elements.nav.contains(e.target);
            const isClickOnToggle = elements.mobileToggle.contains(e.target);
            
            if (!isClickInsideNav && !isClickOnToggle) {
                closeMobileMenu();
            }
        });
    }
    
    /**
     * Setup smooth scroll for anchor links
     */
    function setupSmoothScroll() {
        elements.navLinks.forEach(link => {
            // Only for anchor links to same page
            if (link.hash && link.pathname === window.location.pathname) {
                link.addEventListener('click', (e) => {
                    e.preventDefault();
                    
                    const targetId = link.hash.slice(1);
                    const targetElement = document.getElementById(targetId);
                    
                    if (targetElement) {
                        smoothScrollTo(targetElement);
                    }
                });
            }
        });
    }
    
    /**
     * Smooth scroll to element with header offset
     */
    function smoothScrollTo(element) {
        const offsetTop = element.getBoundingClientRect().top + window.scrollY;
        const scrollTo = offsetTop - CONFIG.headerHeight - 20; // Header + buffer
        
        window.scrollTo({
            top: scrollTo,
            behavior: 'smooth'
        });
    }
    
    /**
     * Setup active link highlighting based on scroll position
     */
    function setupActiveLinks() {
        if (elements.navLinks.length === 0) return;
        
        // Get all sections with IDs
        const sections = Array.from(document.querySelectorAll('section[id]'));
        
        if (sections.length === 0) return;
        
        // Throttled scroll handler
        let ticking = false;
        window.addEventListener('scroll', () => {
            if (!ticking) {
                window.requestAnimationFrame(() => {
                    updateActiveLink(sections);
                    ticking = false;
                });
                ticking = true;
            }
        });
        
        // Initial check
        updateActiveLink(sections);
    }
    
    /**
     * Update active link based on current scroll position
     */
    function updateActiveLink(sections) {
        const scrollY = window.scrollY + CONFIG.headerHeight + 100;
        
        // Find current section
        let currentSection = null;
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            
            if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
                currentSection = section;
            }
        });
        
        // Update nav links
        elements.navLinks.forEach(link => {
            link.classList.remove('active');
            
            if (currentSection && link.hash === `#${currentSection.id}`) {
                link.classList.add('active');
            }
            
            // Special case: home link active at top
            if (link.getAttribute('href') === 'index.html' && scrollY < 200) {
                link.classList.add('active');
            }
        });
    }
    
    /**
     * Announce to screen readers
     */
    function announceToScreenReader(message) {
        const announcement = document.createElement('div');
        announcement.setAttribute('role', 'status');
        announcement.setAttribute('aria-live', 'polite');
        announcement.className = 'sr-only';
        announcement.textContent = message;
        
        document.body.appendChild(announcement);
        
        setTimeout(() => {
            document.body.removeChild(announcement);
        }, 1000);
    }
    
    /**
     * Debounce utility
     */
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    /**
     * Fix viewport height for mobile (100vh bug)
     */
    function fixMobileVH() {
        const vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    }
    
    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    // Fix mobile VH on resize
    window.addEventListener('resize', debounce(fixMobileVH, 250));
    fixMobileVH();
    
    // Expose public API
    window.NavigationEnhanced = {
        openMobileMenu,
        closeMobileMenu,
        toggleMobileMenu
    };
    
})();

/**
 * Add screen reader only utility class
 */
const style = document.createElement('style');
style.textContent = `
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border-width: 0;
    }
`;
document.head.appendChild(style);
